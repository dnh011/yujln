import React from 'react';
import ExpenseItem from './ExpenseItem';

const ExpenseList = ({ initialExpenses, handleDelete }) => {
    console.log(initialExpenses);
  return (
    <>
      <ul className='list'>
        {initialExpenses.map(expense => {
          return <ExpenseItem handleDelete={handleDelete} key={expense.id} expense={expense} />
        })
        }
      </ul>
      <button>목록 지우기</button>
    </>
  );
};

export default ExpenseList;
