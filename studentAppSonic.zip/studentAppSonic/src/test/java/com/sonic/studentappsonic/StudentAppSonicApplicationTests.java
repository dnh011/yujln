package com.sonic.studentappsonic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentAppSonicApplicationTests {

  @Test
  void contextLoads() {
  }

}
