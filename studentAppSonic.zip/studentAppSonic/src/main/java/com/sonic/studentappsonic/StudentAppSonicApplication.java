package com.sonic.studentappsonic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentAppSonicApplication {

  public static void main(String[] args) {
    SpringApplication.run(StudentAppSonicApplication.class, args);
  }

}
