package com.sonic.studentappsonic.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class InputRestriction {
  private int maxGrade;
}
